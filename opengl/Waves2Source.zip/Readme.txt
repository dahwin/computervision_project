This is the Wave generator Program by Ian Mallett, made in 2008.

To Use, just run Waves.exe.  There are four waves (top, white) that are mixed real-time to form the resultant (bottom, red).  
If you want to change the waves, (and you will), open Waves.txt.  Enter in the Wave data you want:

40 10
30 5
7 34
9 39

You will enter the first number, which corresponds to amplitude, and the second, which corresponds to frequency, with a single space in-between.

I recommend that the amplitude you enter on the waves not be bigger than 50.  After 50, they will overflow into the other rows.  (However, the resultant will often go over 50.  For this reason, I made it twice as big as the others, and I don't let it leave that area).

Frequencies over about 25 will become incoherent.  

Have fun!

Ian